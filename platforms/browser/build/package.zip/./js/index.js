/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

$(document).ready(function() {

    var data;  // Made this global for some reason that I don't remember; might be possible to deglobalize

    // Makes sure everything happens after the device is ready
    // Otherwise it may not work due to asynchronization
    document.addEventListener("deviceready", function() {

        // Supposedly aliases "click" and "touch" actions so that something written using "click"
        // will work with "touch" and vice versa
        document.addEventListener("touchstart", function(){}, true);

        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onFileSystemSuccess, fail);

        var template;
        $.ajax("./js/buttons.json", {
            dataType: "text",
            success: function(data) {
                template = data;
                console.log(template);
            }
        })

        function onFileSystemSuccess(fileSystem) {
            fileSystem.root.getDirectory("sounds", {create: true}, onNewDirectorySuccess, fail);
            fileSystem.root.getFile("buttons.json", {create: true}, onNewFileSuccess, fail);
        }

        function onNewDirectorySuccess(parent) {
            console.log("sounds directory");
        }

        function onNewFileSuccess(file) {
            file.createWriter(madeFileWriter, fail);
        }

        function madeFileWriter(writer) {
            // if (writer.length < 1) {
            //     writer.write(template);
            //     console.log("new");
            // }
        }

        function fail(error) {
            console.log(error.code);
        }

    
        // This opens the JSON file that holds the sounds/sound info
        var request = new XMLHttpRequest();
        request.open('GET', 'buttons.json', true);

        // Once the JSON file is loaded, do all the stuff in here
        request.onload = function() {

            if (request.status >= 200 && request.status < 400) {

                data = JSON.parse(request.response).buttonList;  // Data is buttonList inside of buttons.JSON
                console.log(data.length);

                // Directives for transparency.js
                // See https://github.com/leonidas/transparency#directives for more details
                var directives = {
                    index: {  // For tags with class index
                        html: function(params) {  // Fill the inner HTML with:
                            // Add a span with data-index="index" to the button
                            return "<span data-index=\"" + this.index + "\"></span>";
                        }
                    }
                };

                // Fills in the HTML using transparency.js
                $(".buttons").render(data, directives);

                var media;

                // When a button with class "button" is clicked
                $(".button").on("click", function() {
                    // Find the span with the index number
                    indexSpan = $(document.activeElement).find("span").not(".name");
                    // Create a new Media object
                    media = new Media(data[indexSpan.data("index")].soundAddress);
                    media.play();  // Play said Media object
                });

                // If the Stop All Sounds button is clicked, stop playback
                $("#stop").on("click", function() {
                    media.stop();
                });

                var jsonFile;

                $("#createNew").on("click", function() {
                    var soundName = document.getElementById("soundName").value;
                    var selectedFile = document.getElementById("location").files[0];
                    var soundLoc = "sounds/" + selectedFile;

                    console.log(selectedFile);

                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onFileSystemSuccess, fail);

                    function onFileSystemSuccess(fileSystem) {
                        fileSystem.root.getFile("buttons.json", {create: false}, onGetFileSuccess, fail);
                    }           

                    

                    function onGetFileSuccess(file) {
                        console.log(file);
                        file.createWriter(gotFileWriter, fail);
                    }

                    function gotFileWriter(writer) {
                        

                        writer.seek(writer.length - 5);
                        writer.write(",\n\n\t\t{\n\t\t\t\"index\": " + data.length + ",\n\t\t\t\"name\": \"" + soundName + "\",\n\t\t\t\"soundAddress\": \"" + selectedFile + "\"\n\t\t}")
                        console.log("entry");
                    }

                    function fail(evt) {
                        console.log(evt.code);
                    }

                    // location.href = "./index.html";
                });
            }
        };

        request.send();

    });

});